import AdminDashboard from '@/components/AdminDashboard';

export default function AdminScreen() {
  return <AdminDashboard />;
}