import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Share,
  Clipboard,
} from 'react-native';
import { Link2, Copy, Share2, Apple as WhatsApp } from 'lucide-react-native';

interface Product {
  id: string;
  name: string;
  originalPrice: number;
  myPrice: number;
}

interface LinkGeneratorProps {
  product: Product;
  sellerId: string;
  sellerName: string;
}

export default function LinkGenerator({ product, sellerId, sellerName }: LinkGeneratorProps) {
  const [customPrice, setCustomPrice] = useState(product.myPrice.toString());
  const [generatedLink, setGeneratedLink] = useState('');

  const generateLink = () => {
    const baseUrl = 'https://mystore.com/buy';
    const params = new URLSearchParams({
      product: product.id,
      seller: sellerId,
      sellerName: sellerName,
      price: customPrice,
      originalPrice: product.originalPrice.toString(),
    });
    
    const link = `${baseUrl}?${params.toString()}`;
    setGeneratedLink(link);
    return link;
  };

  const copyToClipboard = async () => {
    const link = generatedLink || generateLink();
    await Clipboard.setStringAsync(link);
    Alert.alert('تم النسخ', 'تم نسخ الرابط إلى الحافظة');
  };

  const shareLink = async () => {
    const link = generatedLink || generateLink();
    const message = `🛍️ ${product.name}\n💰 السعر: $${customPrice}\n\n🔗 اطلب الآن من خلال الرابط:\n${link}`;
    
    try {
      await Share.share({
        message: message,
        url: link,
      });
    } catch (error) {
      Alert.alert('خطأ', 'حدث خطأ في المشاركة');
    }
  };

  const shareWhatsApp = () => {
    const link = generatedLink || generateLink();
    const message = `🛍️ ${product.name}%0A💰 السعر: $${customPrice}%0A%0A🔗 اطلب الآن:%0A${link}`;
    const whatsappUrl = `whatsapp://send?text=${message}`;
    
    // في التطبيق الحقيقي، ستستخدم Linking.openURL
    Alert.alert('واتساب', 'سيتم فتح واتساب لمشاركة الرابط');
  };

  const profit = parseFloat(customPrice) - product.originalPrice;
  const profitPercentage = ((profit / product.originalPrice) * 100).toFixed(1);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>إنشاء رابط البيع</Text>
      
      <View style={styles.productInfo}>
        <Text style={styles.productName}>{product.name}</Text>
        <Text style={styles.originalPrice}>السعر الأصلي: ${product.originalPrice}</Text>
      </View>

      <View style={styles.priceSection}>
        <Text style={styles.label}>سعر البيع:</Text>
        <TextInput
          style={styles.priceInput}
          value={customPrice}
          onChangeText={setCustomPrice}
          keyboardType="numeric"
          placeholder="أدخل سعر البيع"
        />
      </View>

      <View style={styles.profitInfo}>
        <View style={styles.profitRow}>
          <Text style={styles.profitLabel}>الربح المتوقع:</Text>
          <Text style={[styles.profitValue, { color: profit > 0 ? '#10B981' : '#EF4444' }]}>
            ${profit.toFixed(2)} ({profitPercentage}%)
          </Text>
        </View>
      </View>

      <TouchableOpacity style={styles.generateButton} onPress={generateLink}>
        <Link2 size={20} color="#FFFFFF" />
        <Text style={styles.generateButtonText}>إنشاء الرابط</Text>
      </TouchableOpacity>

      {generatedLink && (
        <View style={styles.linkSection}>
          <Text style={styles.linkLabel}>الرابط المُنشأ:</Text>
          <View style={styles.linkContainer}>
            <Text style={styles.linkText} numberOfLines={2}>
              {generatedLink}
            </Text>
          </View>

          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.copyButton} onPress={copyToClipboard}>
              <Copy size={16} color="#3B82F6" />
              <Text style={styles.copyButtonText}>نسخ</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.shareButton} onPress={shareLink}>
              <Share2 size={16} color="#FFFFFF" />
              <Text style={styles.shareButtonText}>مشاركة</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.whatsappButton} onPress={shareWhatsApp}>
              <Text style={styles.whatsappButtonText}>واتساب</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 20,
    margin: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 15,
    textAlign: 'center',
  },
  productInfo: {
    backgroundColor: '#F3F4F6',
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
  },
  productName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 5,
  },
  originalPrice: {
    fontSize: 14,
    color: '#6B7280',
  },
  priceSection: {
    marginBottom: 15,
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 8,
  },
  priceInput: {
    borderWidth: 1,
    borderColor: '#D1D5DB',
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 16,
    backgroundColor: '#FFFFFF',
  },
  profitInfo: {
    backgroundColor: '#EFF6FF',
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
  },
  profitRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  profitLabel: {
    fontSize: 14,
    color: '#374151',
  },
  profitValue: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  generateButton: {
    backgroundColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    gap: 8,
    marginBottom: 15,
  },
  generateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  linkSection: {
    borderTopWidth: 1,
    borderTopColor: '#E5E7EB',
    paddingTop: 15,
  },
  linkLabel: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 8,
  },
  linkContainer: {
    backgroundColor: '#F9FAFB',
    padding: 12,
    borderRadius: 8,
    marginBottom: 15,
  },
  linkText: {
    fontSize: 12,
    color: '#4B5563',
    lineHeight: 16,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  copyButton: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#3B82F6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    gap: 5,
  },
  copyButtonText: {
    color: '#3B82F6',
    fontWeight: '600',
  },
  shareButton: {
    flex: 1,
    backgroundColor: '#6B7280',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    gap: 5,
  },
  shareButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  whatsappButton: {
    flex: 1,
    backgroundColor: '#25D366',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
  },
  whatsappButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
});