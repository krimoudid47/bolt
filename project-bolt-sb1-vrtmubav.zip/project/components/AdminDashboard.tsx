import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Package, User, Phone, MapPin, Clock, CircleCheck as CheckCircle, Circle as XCircle } from 'lucide-react-native';

interface AdminOrder {
  id: string;
  productId: string;
  productName: string;
  sellerId: string;
  sellerName: string;
  customerInfo: {
    name: string;
    phone: string;
    address: string;
    notes: string;
  };
  price: number;
  originalPrice: number;
  profit: number;
  orderDate: string;
  status: 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';
}

// بيانات وهمية للطلبات
const mockAdminOrders: AdminOrder[] = [
  {
    id: 'ORD001',
    productId: '1',
    productName: 'ساعة ذكية رياضية',
    sellerId: 'user123',
    sellerName: 'أحمد محمد',
    customerInfo: {
      name: 'سارة علي',
      phone: '+966501234567',
      address: 'الرياض، حي النخيل، شارع الملك فهد، مبنى 123',
      notes: 'يفضل التسليم مساءً',
    },
    price: 200,
    originalPrice: 150,
    profit: 50,
    orderDate: '2024-01-15T10:30:00Z',
    status: 'pending',
  },
  {
    id: 'ORD002',
    productId: '2',
    productName: 'سماعات لاسلكية',
    sellerId: 'user456',
    sellerName: 'فاطمة أحمد',
    customerInfo: {
      name: 'محمد السعد',
      phone: '+966507654321',
      address: 'جدة، حي الصفا، طريق الأمير سلطان، فيلا 456',
      notes: 'اللون الأسود مفضل',
    },
    price: 120,
    originalPrice: 80,
    profit: 40,
    orderDate: '2024-01-14T14:15:00Z',
    status: 'confirmed',
  },
];

export default function AdminDashboard() {
  const [orders, setOrders] = useState<AdminOrder[]>(mockAdminOrders);

  const updateOrderStatus = (orderId: string, newStatus: AdminOrder['status']) => {
    setOrders(orders.map(order => 
      order.id === orderId ? { ...order, status: newStatus } : order
    ));
    Alert.alert('تم التحديث', 'تم تحديث حالة الطلب بنجاح');
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return '#F59E0B';
      case 'confirmed': return '#3B82F6';
      case 'shipped': return '#8B5CF6';
      case 'delivered': return '#10B981';
      case 'cancelled': return '#EF4444';
      default: return '#6B7280';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'في الانتظار';
      case 'confirmed': return 'مؤكد';
      case 'shipped': return 'تم الشحن';
      case 'delivered': return 'تم التسليم';
      case 'cancelled': return 'ملغي';
      default: return status;
    }
  };

  const AdminOrderCard = ({ order }: { order: AdminOrder }) => (
    <View style={styles.orderCard}>
      {/* رأس الطلب */}
      <View style={styles.orderHeader}>
        <View style={styles.orderInfo}>
          <Text style={styles.orderId}>#{order.id}</Text>
          <Text style={styles.orderDate}>
            {new Date(order.orderDate).toLocaleDateString('ar-SA')}
          </Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: getStatusColor(order.status) + '20' }]}>
          <Text style={[styles.statusText, { color: getStatusColor(order.status) }]}>
            {getStatusText(order.status)}
          </Text>
        </View>
      </View>

      {/* معلومات المنتج */}
      <View style={styles.productSection}>
        <Package size={16} color="#6B7280" />
        <View style={styles.productInfo}>
          <Text style={styles.productName}>{order.productName}</Text>
          <Text style={styles.productPrice}>السعر: ${order.price}</Text>
        </View>
      </View>

      {/* معلومات البائع */}
      <View style={styles.sellerSection}>
        <Text style={styles.sectionTitle}>البائع:</Text>
        <View style={styles.sellerInfo}>
          <User size={16} color="#3B82F6" />
          <Text style={styles.sellerName}>{order.sellerName}</Text>
          <Text style={styles.sellerId}>({order.sellerId})</Text>
        </View>
        <Text style={styles.profitInfo}>ربح البائع: ${order.profit}</Text>
      </View>

      {/* معلومات العميل */}
      <View style={styles.customerSection}>
        <Text style={styles.sectionTitle}>العميل:</Text>
        
        <View style={styles.customerRow}>
          <User size={16} color="#6B7280" />
          <Text style={styles.customerText}>{order.customerInfo.name}</Text>
        </View>
        
        <View style={styles.customerRow}>
          <Phone size={16} color="#6B7280" />
          <Text style={styles.customerText}>{order.customerInfo.phone}</Text>
        </View>
        
        <View style={styles.customerRow}>
          <MapPin size={16} color="#6B7280" />
          <Text style={styles.customerText}>{order.customerInfo.address}</Text>
        </View>
        
        {order.customerInfo.notes && (
          <View style={styles.notesSection}>
            <Text style={styles.notesTitle}>ملاحظات:</Text>
            <Text style={styles.notesText}>{order.customerInfo.notes}</Text>
          </View>
        )}
      </View>

      {/* أزرار الإجراءات */}
      {order.status === 'pending' && (
        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={styles.confirmButton}
            onPress={() => updateOrderStatus(order.id, 'confirmed')}
          >
            <CheckCircle size={16} color="#FFFFFF" />
            <Text style={styles.buttonText}>تأكيد</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.cancelButton}
            onPress={() => updateOrderStatus(order.id, 'cancelled')}
          >
            <XCircle size={16} color="#FFFFFF" />
            <Text style={styles.buttonText}>إلغاء</Text>
          </TouchableOpacity>
        </View>
      )}

      {order.status === 'confirmed' && (
        <TouchableOpacity
          style={styles.shipButton}
          onPress={() => updateOrderStatus(order.id, 'shipped')}
        >
          <Package size={16} color="#FFFFFF" />
          <Text style={styles.buttonText}>تم الشحن</Text>
        </TouchableOpacity>
      )}

      {order.status === 'shipped' && (
        <TouchableOpacity
          style={styles.deliverButton}
          onPress={() => updateOrderStatus(order.id, 'delivered')}
        >
          <CheckCircle size={16} color="#FFFFFF" />
          <Text style={styles.buttonText}>تم التسليم</Text>
        </TouchableOpacity>
      )}
    </View>
  );

  const pendingOrders = orders.filter(order => order.status === 'pending').length;
  const totalRevenue = orders
    .filter(order => order.status === 'delivered')
    .reduce((sum, order) => sum + order.originalPrice, 0);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>لوحة تحكم الأدمن</Text>
      </View>

      {/* إحصائيات سريعة */}
      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{pendingOrders}</Text>
          <Text style={styles.statLabel}>طلبات جديدة</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>{orders.length}</Text>
          <Text style={styles.statLabel}>إجمالي الطلبات</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statNumber}>${totalRevenue}</Text>
          <Text style={styles.statLabel}>إجمالي المبيعات</Text>
        </View>
      </View>

      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        {orders.map(order => (
          <AdminOrderCard key={order.id} order={order} />
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9FAFB',
  },
  header: {
    paddingHorizontal: 20,
    paddingVertical: 15,
    backgroundColor: '#FFFFFF',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#1F2937',
  },
  statsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 15,
    paddingVertical: 15,
    gap: 10,
  },
  statCard: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 15,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  statNumber: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#3B82F6',
  },
  statLabel: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 5,
  },
  scrollView: {
    flex: 1,
    paddingHorizontal: 15,
  },
  orderCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    padding: 15,
    marginVertical: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  orderHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
  },
  orderInfo: {
    flex: 1,
  },
  orderId: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1F2937',
  },
  orderDate: {
    fontSize: 12,
    color: '#6B7280',
    marginTop: 2,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },
  productSection: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#F9FAFB',
    borderRadius: 8,
  },
  productInfo: {
    marginLeft: 10,
    flex: 1,
  },
  productName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1F2937',
  },
  productPrice: {
    fontSize: 12,
    color: '#059669',
    marginTop: 2,
  },
  sellerSection: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#EFF6FF',
    borderRadius: 8,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#1F2937',
    marginBottom: 8,
  },
  sellerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
  sellerName: {
    fontSize: 14,
    color: '#3B82F6',
    marginLeft: 8,
    fontWeight: '600',
  },
  sellerId: {
    fontSize: 12,
    color: '#6B7280',
    marginLeft: 5,
  },
  profitInfo: {
    fontSize: 12,
    color: '#059669',
    fontWeight: '600',
  },
  customerSection: {
    marginBottom: 15,
    padding: 10,
    backgroundColor: '#F0FDF4',
    borderRadius: 8,
  },
  customerRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 8,
  },
  customerText: {
    fontSize: 14,
    color: '#374151',
    marginLeft: 8,
    flex: 1,
  },
  notesSection: {
    marginTop: 8,
    padding: 8,
    backgroundColor: '#FFFFFF',
    borderRadius: 6,
  },
  notesTitle: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#6B7280',
    marginBottom: 4,
  },
  notesText: {
    fontSize: 12,
    color: '#4B5563',
    fontStyle: 'italic',
  },
  actionButtons: {
    flexDirection: 'row',
    gap: 10,
  },
  confirmButton: {
    flex: 1,
    backgroundColor: '#10B981',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    gap: 5,
  },
  cancelButton: {
    flex: 1,
    backgroundColor: '#EF4444',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    gap: 5,
  },
  shipButton: {
    backgroundColor: '#8B5CF6',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    gap: 5,
  },
  deliverButton: {
    backgroundColor: '#10B981',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    gap: 5,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 14,
  },
});